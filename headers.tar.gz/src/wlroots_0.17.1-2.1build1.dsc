-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: wlroots
Binary: libwlroots-dev, libwlroots12t64, libwlroots-examples
Architecture: any
Version: 0.17.1-2.1build1
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>
Uploaders: Guido Günther <agx@sigxcpu.org>, Birger Schacht <birger@rantanplan.org>
Homepage: https://gitlab.freedesktop.org/wlroots/wlroots/
Standards-Version: 4.6.2
Vcs-Browser: https://salsa.debian.org/swaywm-team/wlroots
Vcs-Git: https://salsa.debian.org/swaywm-team/wlroots.git
Testsuite: autopkgtest
Testsuite-Triggers: build-essential, pkg-config
Build-Depends: dpkg-dev (>= 1.22.5), debhelper-compat (= 13), glslang-tools, hwdata, libcap-dev, libcairo2-dev, libdisplay-info-dev (>= 0.1.1), libdrm-dev (>= 2.4.114), libegl1-mesa-dev, libegl-dev, libgbm-dev, libgles2-mesa-dev, libinput-dev, libliftoff-dev (>= 0.4.1), libpixman-1-dev, libpng-dev, libseat-dev, libsystemd-dev, libvulkan-dev, libwayland-dev (>= 1.22), libx11-xcb-dev, libxcb1-dev, libxcb-composite0-dev, libxcb-dri3-dev, libxcb-ewmh-dev, libxcb-icccm4-dev, libxcb-image0-dev, libxcb-present-dev, libxcb-render0-dev, libxcb-render-util0-dev, libxcb-res0-dev, libxcb-shm0-dev, libxcb-xfixes0-dev, libxcb-xinput-dev, libxkbcommon-dev, meson, pkg-config, wayland-protocols (>= 1.24), xwayland
Package-List:
 libwlroots-dev deb libdevel optional arch=any
 libwlroots-examples deb libs optional arch=any
 libwlroots12t64 deb libs optional arch=any
Checksums-Sha1:
 de59d85f73ac1bda95b63523dcac295c8edcb66f 607838 wlroots_0.17.1.orig.tar.gz
 8406ecad8f7d2495d8b9b52d1669b40849b87271 11396 wlroots_0.17.1-2.1build1.debian.tar.xz
Checksums-Sha256:
 b4b1b08daf0728cd2648fb57660493e5b3eafe4fcc081c138de864895181cdfe 607838 wlroots_0.17.1.orig.tar.gz
 46bebf5b92e31cb1155bd7e8ec6f70fcabe6ba0d4bab88023a70acd7f0dfea1e 11396 wlroots_0.17.1-2.1build1.debian.tar.xz
Files:
 bb617f0fcc85ed179eec818d8d5d503b 607838 wlroots_0.17.1.orig.tar.gz
 39a4b551665661d6c8e0dbfe99693f6d 11396 wlroots_0.17.1-2.1build1.debian.tar.xz
Original-Maintainer: Sway and related packages team <team+swaywm@tracker.debian.org>

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEoIn7Nqr72tWswTJQafeQFxohCYQFAmYKO00ACgkQafeQFxoh
CYTh7RAAwYIfwLjCH5QpID9zBPHf4hw4jTdwijnTvZzJ8mi8tYcpcgumseFL/8CM
9gW2ibZNw2OaaUSHbLJ0CshuHUpA/LTbfe9MAWNQV+WNYLHE/zPA3PBgM05E6OEp
QOCuEcHxYqD5B5/kSyE+jrKpGzrA6eMpYicr2xT2MwJ1Wxi1N2Ajyq9oPilEsJOW
SxuMK0PsqiMMjtJ31WfavnrOarrIbVNU8EO8tBUmV0oz0rYE9EoWzRqAA3urn00l
MDQ3D5WVyB2hGXn9nYwTDZ2vLT/gvT7DfIXFR/4gkq4VXBfzOwZlQPPOT1D8DMOQ
b310ifGGKCZQO+x0SB+9yYOOeJ95oKxHZBFlECi/Y9KYKm8GvPsqpFj7NRUDdNIh
b/jfZeSLfiWgTpOrzvRV3PnCLnWob+BGPaN70MZ27NY1z1z0Xz3SVYzF9c8ucLoW
ATFcjW/mRaFGAyCNlYJzSjc9mxnZ0IshrfBkijharquD34GPb7NIzZtBj9ch1Gyz
ds/xD89KIM8Uv0ZrsvYiwcOFk4DRN+meCBYXxXOjTuRSRubR9dL6o6B18k+aNi2k
o4nK3O0A/B2hr+b8Qjj+jZxLNGrLv9N3dkEL2H1Ih1BP4UH0u/+DmaY4ydSXsy6u
QI74JiQ1ZhdY1rBaMg/DeuZtp0h4NdD7mzuQZOmSxmT7Fd+TaI0=
=bFwj
-----END PGP SIGNATURE-----
